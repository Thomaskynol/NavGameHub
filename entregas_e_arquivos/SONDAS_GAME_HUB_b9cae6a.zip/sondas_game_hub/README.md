# Sondas da revisão independente — Game Hub

Estas sondas descrevem a versão revisada no pacote de SHA-256
`a6f4a3ff7c27726eb4b4f1c3bcd8600f4fa93f0d12132d392baec1f8a8feae6d`
(commit `b9cae6a` informado pelo relatório; metadados Git não estavam no ZIP).

São **reproduções de falhas**, não uma suíte de aceite. Na versão revisada, exit
0 significa que a condição problemática foi reproduzida; depois de corrigida,
elas podem falhar, dar timeout ou exigir adaptação. Crie testes de regressão
permanentes com asserções positivas para a implementação corrigida.

Não modifique nem rode contra dados reais ou uma instalação de produção. As
sondas usam portas efêmeras e serviços locais controlados; `reproduce_stale_pid.py`
cria uma cópia temporária do `stop.sh` e um processo `sleep` descartável próprio.
A sonda de colisão força um código igual e sincroniza duas verificações; não é
uma alegação de que uma colisão aleatória aconteceu em uma partida real.

As sondas JS precisam da dependência `ws` já instalada na raiz do projeto. Execute
fora do projeto ou em um diretório temporário, informando o caminho da raiz:

```bash
node reproduce_collision.mjs '/caminho/para/Game Hub'
node reproduce_orphan_cleanup.mjs '/caminho/para/Game Hub'
node reproduce_arcade_reconnect.mjs '/caminho/para/Game Hub'
node reproduce_pregame_join.mjs '/caminho/para/Game Hub'
node reproduce_disconnect_autostart.mjs '/caminho/para/Game Hub'
node reproduce_game_server_crash.mjs '/caminho/para/Game Hub'
node reproduce_port_override.mjs '/caminho/para/Game Hub'
python3 reproduce_stale_pid.py '/caminho/para/Game Hub'
node --experimental-transform-types reproduce_catan_closed_code.mjs '/caminho/para/Game Hub'
```

`reproduce_catan_closed_code.mjs` importa diretamente o TypeScript de persistência
e foi executado na revisão com Node 24 e transformação de tipos nativa. Outras
versões podem precisar do `tsx` já usado pelo projeto. Ela usa SQLite em memória.

`reproduce_port_override.mjs` usa uma sonda de saúde controlada para observar a
porta que o Hub fornece ao health-check, sem atingir um eventual processo na
porta padrão. A revisão também verificou o comportamento do health-check padrão
em um ambiente isolado com essa porta livre.
