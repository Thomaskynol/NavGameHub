// A closed Catan room code is absent from open rooms but remains occupied in SQLite.
// Run on Node 24 with --experimental-transform-types (or adapt to the project's tsx).
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const root=path.resolve(process.argv[2]||process.cwd());
const dbModule=await import(pathToFileURL(path.join(root,'Games/Catan/src/server/db.ts')).href);
const db=dbModule.openDb(':memory:');
try {
  dbModule.insertRoom(db,{code:'ABCDEF',name:'old',hostPlayerId:'p1',phase:'lobby',version:0,boardSeed:'test',createdAt:1});
  dbModule.persistRoomUpdate(db,{roomCode:'ABCDEF',closed:true,updatedAt:2});
  const occupied=dbModule.roomCodeExists(db,'ABCDEF');
  const open=dbModule.loadOpenRooms(db).rooms.length;
  console.log('Closed code exists in SQLite:',occupied);
  console.log('Open rooms loaded:',open);
  if(!occupied||open!==0)throw new Error('Expected inconsistency not reproduced');
} finally { db.close(); }
