import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: exercise the actual Arcade room server.
// The Hub-mode client currently sends join without the stored resume token.
const { startServer } = await import(fromRoot('Games/ArcadeAI_race_game/server/index.js'));
const wsModule = requireProject('ws');
const WebSocket = wsModule.default || wsModule;

const game=await startServer({port:0,host:'127.0.0.1',secret:'review-only'});
const sockets=[];
async function connect() {
  const socket=new WebSocket(`ws://127.0.0.1:${game.port}/ws`);
  await new Promise((resolve,reject)=>{socket.once('open',resolve);socket.once('error',reject);});
  sockets.push(socket);return socket;
}
async function command(socket,msg) {
  const result=new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('timeout')),3000);
    function onmsg(data){const value=JSON.parse(data.toString());if(value.t==='joined'||value.t==='err'){clearTimeout(timer);socket.off('message',onmsg);resolve(value);}}
    socket.on('message',onmsg);
  });
  socket.send(JSON.stringify(msg));return result;
}
try {
  const host=await connect();
  const first=await command(host,{t:'create',room:'ABCDEF',name:'Alice'});
  if(first.t!=='joined') throw new Error('create failed');
  for(let i=2;i<=6;i++){
    const s=await connect();
    const joined=await command(s,{t:'join',room:'ABCDEF',name:`Player${i}`});
    if(joined.t!=='joined') throw new Error(`join ${i} failed`);
  }
  host.terminate();
  const end=Date.now()+2000;
  while(game.rooms.getRoom('ABCDEF').players.find(p=>p.id===first.you).conn!==null){
    if(Date.now()>end) throw new Error('disconnect not observed');
    await new Promise(resolve=>setTimeout(resolve,5));
  }
  const fresh=await connect();
  const noResume=await command(fresh,{t:'join',room:'ABCDEF',name:'Alice'});
  const resumed=await connect();
  const withResume=await command(resumed,{t:'join',room:'ABCDEF',name:'Alice',resume:first.token});
  console.log('Six-slot room; same player reconnects while old slot is retained');
  console.log('Join without stored resume token:',noResume.t,noResume.code);
  console.log('Join with original resume token:',withResume.t,'same player:',withResume.you===first.you);
  if(noResume.code!=='FULL'||withResume.t!=='joined'||withResume.you!==first.you) throw new Error('Expected behavior not reproduced');
} finally {
  for(const socket of sockets) socket.terminate();
  await game.close();
}
