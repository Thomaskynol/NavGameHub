import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: controlled health service on an alternate port.
import { createServer } from 'node:http';
const { createHub } = await import(fromRoot('hub/server.js'));
const { connectClient } = await import(fromRoot('hub/test/helpers.mjs'));

const arcade=createServer((req,res)=>{res.writeHead(200,{'content-type':'application/json'});res.end('{"ok":true}');});
await new Promise(resolve=>arcade.listen(0,'127.0.0.1',resolve));
const arcadePort=arcade.address().port;
process.env.ARCADE_PORT=String(arcadePort);
const observed=[];
const hub=createHub({secret:'review',log:()=>{},timings:{healthInterval:0,healthTimeout:500},probe:async game=>{
  observed.push({id:game.id,port:game.port});
  if(game.id!=='arcade'||game.port!==arcadePort)return false;
  return (await fetch(`http://127.0.0.1:${game.port}/api/info`)).ok;
}});
const addr=await hub.listen(0,'127.0.0.1');
const client=await connectClient(addr.port);
try {
  await client.hello({nick:'PortProbe'});
  const catalog=await client.next(m=>m.t==='catalog');
  const status=catalog.games.find(g=>g.id==='arcade')?.status;
  const health=await fetch(`http://127.0.0.1:${arcadePort}/api/info`);
  console.log('Controlled service configured ARCADE_PORT:',arcadePort,'health status:',health.status);
  console.log('Ports supplied to health probe:',JSON.stringify(observed));
  console.log('Hub catalog status for Arcade:',status,'(manifest fixed port 8091)');
  if(arcadePort===8091||health.status!==200||status!=='offline') throw new Error('Unexpected local environment or result');
} finally {
  await client.close(); await hub.close(); await new Promise(resolve=>arcade.close(resolve)); delete process.env.ARCADE_PORT;
}
