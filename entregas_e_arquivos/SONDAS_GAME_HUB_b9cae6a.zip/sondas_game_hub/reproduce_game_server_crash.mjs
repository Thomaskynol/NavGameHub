// A game endpoint stops responding while the Hub room is playing.
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const root=path.resolve(process.argv[2]||process.cwd());
const {connectClient,startFakeGame,startTestHub,waitForCondition}=await import(
  pathToFileURL(path.join(root,'hub/test/helpers.mjs')).href);
const fake=await startFakeGame({id:'arcade'});
const {hub,port}=await startTestHub({ports:{arcade:fake.port},timings:{healthInterval:40,healthTimeout:50,playPollInterval:25,stateTimeout:50}});
const clients=[];
let fakeClosed=false;
try {
  for(const nick of ['CrashA','CrashB']){const c=await connectClient(port);await c.hello({nick});clients.push(c);}
  const [a,b]=clients;
  a.send({t:'create_room',gameId:'arcade',capacity:2});const room=(await a.next(m=>m.t==='room')).room;
  b.send({t:'join_room',code:room.code});await b.next(m=>m.t==='room');
  const play=a.next(m=>m.t==='play',3000);a.send({t:'set_ready',ready:true});b.send({t:'set_ready',ready:true});
  const code=new URL((await play).url).searchParams.get('room');fake.createRoom(code,{phase:'playing',players:2,capacity:2,joinable:false});
  await waitForCondition(()=>hub.snapshot().rooms[0]?.phase==='playing',2000);
  await fake.close();fakeClosed=true;
  await new Promise(resolve=>setTimeout(resolve,350));
  const current=hub.snapshot().rooms[0];
  a.send({t:'set_game',gameId:'arcade'});
  const response=await a.next(m=>m.t==='error'&&m.code==='BAD_PHASE',1000);
  console.log('Hub phase after game endpoint stopped:',current.phase);
  console.log('Host cannot change game:',response.code);
  if(current.phase!=='playing'||response.code!=='BAD_PHASE')throw new Error('Expected stranded state not reproduced');
} finally {
  for(const c of clients){if(c.ws.readyState!==3)c.ws.terminate();}
  await hub.close();if(!fakeClosed)await fake.close();
}
