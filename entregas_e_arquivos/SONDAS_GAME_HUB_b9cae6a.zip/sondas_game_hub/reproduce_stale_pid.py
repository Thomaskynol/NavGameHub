#!/usr/bin/env python3
"""Safe probe: stop.sh only receives the PID of a disposable test child."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading

root = Path(sys.argv[1] if len(sys.argv) > 1 else os.getcwd()).resolve()
source = root / 'stop.sh'
with tempfile.TemporaryDirectory(prefix='hub-review-pid-') as temp:
    directory = Path(temp)
    shutil.copy2(source, directory / 'stop.sh')
    pid_directory = directory / '.run/pids'
    pid_directory.mkdir(parents=True)
    child = subprocess.Popen(['sleep', '30'], start_new_session=True)
    threading.Thread(target=child.wait, daemon=True).start()
    (pid_directory / 'hub.pid').write_text(str(child.pid))
    try:
        result = subprocess.run(['bash', str(directory / 'stop.sh')], capture_output=True, text=True, timeout=15)
        print('stop exit:', result.returncode)
        print(result.stdout.strip())
        print('unrelated controlled process exit:', child.poll())
        if child.poll() != -15:
            raise SystemExit('Bug not reproduced: disposable process was not terminated by SIGTERM')
    finally:
        if child.poll() is None:
            child.terminate()
            child.wait()
