import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: all users leave immediately after a match returns.
const { connectClient, startFakeGame, startTestHub, waitForCondition } = await import(fromRoot('hub/test/helpers.mjs'));
const fake=await startFakeGame({id:'arcade'});
const {hub,port}=await startTestHub({ports:{arcade:fake.port},timings:{graceDefault:35,closeDelay:500,launchPollInterval:10,playPollInterval:15}});
const clients=[];
try {
  for(const nick of ['GuestA','GuestB']){const c=await connectClient(port);await c.hello({nick});clients.push(c);}
  const [a,b]=clients;
  a.send({t:'create_room',gameId:'arcade',capacity:2});const code=(await a.next(m=>m.t==='room')).room.code;
  b.send({t:'join_room',code});await b.next(m=>m.t==='room');
  const play=a.next(m=>m.t==='play',3000);a.send({t:'set_ready',ready:true});b.send({t:'set_ready',ready:true});
  const gameCode=new URL((await play).url).searchParams.get('room');
  fake.createRoom(gameCode,{phase:'lobby',players:2,capacity:2,joinable:true});
  await waitForCondition(()=>hub.snapshot().rooms[0]?.phase==='playing');
  fake.setRoom(gameCode,{phase:'results'});
  await waitForCondition(()=>hub.snapshot().rooms[0]?.phase==='lobby',2000);
  a.send({t:'leave_room'});b.send({t:'leave_room'});
  await waitForCondition(()=>hub.snapshot().rooms.length===0,1000);
  await new Promise(resolve=>setTimeout(resolve,650));
  const closeRequests=fake.requests.filter(r=>r.path==='/__hub/close'&&r.room===gameCode);
  console.log('Hub room removed:',hub.snapshot().rooms.length===0);
  console.log('Game room still exists after cleanup delay:',fake.rooms.has(gameCode));
  console.log('Game close requests:',closeRequests.length);
  if(!fake.rooms.has(gameCode)||closeRequests.length!==0)throw new Error('Expected cleanup cancellation not reproduced');
} finally {
  for(const c of clients){if(c.ws.readyState!==3)c.ws.terminate();}
  await hub.close();await fake.close();
}
