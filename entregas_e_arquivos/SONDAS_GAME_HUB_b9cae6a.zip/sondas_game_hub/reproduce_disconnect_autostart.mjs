import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: a not-ready Hub member disconnects during grace.
const { connectClient, startFakeGame, startTestHub, waitForCondition } = await import(fromRoot('hub/test/helpers.mjs'));
const fake=await startFakeGame({id:'arcade'});
const {hub,port}=await startTestHub({ports:{arcade:fake.port},timings:{disconnectGrace:3000,launchTimeout:1000}});
const clients=[];
try {
  for(const nick of ['ReadyA','ReadyB','NotReady']){const c=await connectClient(port);await c.hello({nick});clients.push(c);}
  const [a,b,c]=clients;
  a.send({t:'create_room',gameId:'arcade',capacity:3});const code=(await a.next(m=>m.t==='room')).room.code;
  b.send({t:'join_room',code});await b.next(m=>m.t==='room');
  c.send({t:'join_room',code});await c.next(m=>m.t==='room');
  a.send({t:'set_ready',ready:true});b.send({t:'set_ready',ready:true});
  await waitForCondition(()=>{const room=hub.snapshot().rooms[0];return room.members.filter(m=>m.ready).length===2&&room.phase==='lobby';});
  c.ws.terminate();
  await waitForCondition(()=>hub.snapshot().rooms[0].phase==='launching',1000);
  const room=hub.snapshot().rooms[0];
  console.log('Hub phase after unready member disconnects:',room.phase);
  console.log('Members:',JSON.stringify(room.members.map(m=>({nick:m.nick,ready:m.ready,connected:m.connected}))));
  if(room.members.length!==3||room.members.find(m=>m.nick==='NotReady').ready!==false)throw new Error('Unexpected state');
} finally {
  for(const c of clients){if(c.ws.readyState!==3)c.ws.terminate();}
  await hub.close();await fake.close();
}
