import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: third person enters while the real Arcade game is still in its lobby.
const { createHub } = await import(fromRoot('hub/server.js'));
const { startServer } = await import(fromRoot('Games/ArcadeAI_race_game/server/index.js'));
const { connectClient } = await import(fromRoot('hub/test/helpers.mjs'));
const wsModule = requireProject('ws');
const WebSocket = wsModule.default || wsModule;
const secret='review-only';
const game=await startServer({port:0,host:'127.0.0.1',secret});
const manifest={games:[{id:'arcade',name:'Arcade',port:game.port,minPlayers:2,maxPlayers:6,
  codeLength:6,midMatchJoin:false,healthPath:'/api/info'}]};
const hub=createHub({manifest,secret,probe:async()=>true,log:()=>{},timings:{healthInterval:0,launchPollInterval:10}});
const addr=await hub.listen(0,'127.0.0.1');
const hubClients=[], gameSockets=[];
async function gameConn(message){
  const ws=new WebSocket(`ws://127.0.0.1:${game.port}/ws`);gameSockets.push(ws);
  await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});
  const result=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('game timeout')),3000);
    ws.on('message',data=>{const msg=JSON.parse(data.toString());if(msg.t==='joined'||msg.t==='err'){clearTimeout(timer);resolve(msg);}});});
  ws.send(JSON.stringify(message));return result;
}
try {
  for(const nick of ['PlayerA','PlayerB','PlayerC']){const c=await connectClient(addr.port);await c.hello({nick});hubClients.push(c);}
  const [a,b,c]=hubClients;
  a.send({t:'create_room',gameId:'arcade',capacity:3});const hubCode=(await a.next(m=>m.t==='room')).room.code;
  b.send({t:'join_room',code:hubCode});await b.next(m=>m.t==='room');
  const aPlay=a.next(m=>m.t==='play',4000);a.send({t:'set_ready',ready:true});b.send({t:'set_ready',ready:true});
  const code=new URL((await aPlay).url).searchParams.get('room');
  const bPlay=b.next(m=>m.t==='play',4000);
  const first=await gameConn({t:'create',room:code,name:'PlayerA'});if(first.t!=='joined')throw new Error('create failed');
  await bPlay;
  const second=await gameConn({t:'join',room:code,name:'PlayerB'});if(second.t!=='joined')throw new Error('join failed');
  const response=await fetch(`http://127.0.0.1:${game.port}/__hub/state?room=${code}`,{headers:{'x-hub-secret':secret}});
  const state=(await response.json()).room;
  c.send({t:'join_room',code:hubCode});
  const joined=await c.next(m=>m.t==='room'&&m.room.you.nick==='PlayerC',3000);
  await new Promise(resolve=>setTimeout(resolve,100));
  console.log('Actual Arcade state:',JSON.stringify({phase:state.phase,joinable:state.joinable,players:state.players}));
  console.log('New Hub member:',JSON.stringify({hubPhase:joined.room.phase,role:joined.room.you.role,gotPlay:c.messages.some(m=>m.t==='play')}));
  if(state.phase!=='lobby'||state.joinable!==true||joined.room.you.role!=='waiting'||c.messages.some(m=>m.t==='play'))throw new Error('Expected behavior not reproduced');
} finally {
  for(const ws of gameSockets)ws.terminate();
  await Promise.all(hubClients.map(c=>c.close()));await hub.close();await game.close();
}
