import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const reviewRoot = path.resolve(process.argv[2] || process.cwd());
const fromRoot = (relative) => pathToFileURL(path.join(reviewRoot, relative)).href;
const requireProject = createRequire(path.join(reviewRoot, 'package.json'));
// Independent review probe: deterministic collision, barrier on state lookups.
// Uses the production Hub and Arcade server from the unpacked snapshot;
// only the coordination proxy and clients are test code.
import crypto from 'node:crypto';
import { syncBuiltinESMExports } from 'node:module';
import { createServer } from 'node:http';

const originalRandomInt = crypto.randomInt;
let roomCodeDigit = 0;
let gameCodes = false;
crypto.randomInt = () => gameCodes ? 2 : Math.floor(roomCodeDigit++ / 6);
syncBuiltinESMExports();

const { createHub } = await import(fromRoot('hub/server.js'));
const { startServer } = await import(fromRoot('Games/ArcadeAI_race_game/server/index.js'));
const { connectClient } = await import(fromRoot('hub/test/helpers.mjs'));
const wsModule = requireProject('ws');
const WebSocket = wsModule.default || wsModule;

const secret = 'review-only-secret';
const arcade = await startServer({ port: 0, host: '127.0.0.1', secret });
let pendingStates = [];
let stateLookups = 0;
const proxy = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if (url.pathname === '/api/info') {
    res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"ok":true}'); return;
  }
  if (url.pathname === '/__hub/state' && stateLookups < 2) {
    stateLookups++;
    pendingStates.push(res);
    if (stateLookups === 2) {
      for (const pending of pendingStates) {
        pending.writeHead(404, { 'content-type': 'application/json' }); pending.end('{"ok":false}');
      }
      pendingStates = [];
    }
    return;
  }
  try {
    const upstream = await fetch(`http://127.0.0.1:${arcade.port}${req.url}`, {
      method: req.method,
      headers: { 'x-hub-secret': secret },
    });
    res.writeHead(upstream.status, { 'content-type': 'application/json' });
    res.end(await upstream.text());
  } catch { res.writeHead(502); res.end(); }
});
await new Promise(resolve => proxy.listen(0, '127.0.0.1', resolve));
const game = { id:'arcade', name:'Arcade', minPlayers:2, maxPlayers:6, codeLength:6,
  midMatchJoin:false, port:proxy.address().port, healthPath:'/api/info' };
const hub = createHub({ manifest:{games:[game]}, secret, log:()=>{}, timings:{healthInterval:0, stateTimeout:3000, launchTimeout:5000} });
const address = await hub.listen(0, '127.0.0.1');
const clients = [];
const gameClients = [];

async function waitWsMessage(ws, pred, timeout=3000) {
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{ws.off('message',onmsg);reject(new Error('game message timeout'));},timeout);
    function onmsg(data){const msg=JSON.parse(data.toString());if(pred(msg)){clearTimeout(timer);ws.off('message',onmsg);resolve(msg);}}
    ws.on('message',onmsg);
  });
}
async function openGame(){
  const ws=new WebSocket(`ws://127.0.0.1:${arcade.port}/ws`);
  await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject);});
  gameClients.push(ws);return ws;
}
try {
  for (const nick of ['Alpha','Bravo','Charlie','Delta']) {
    const c=await connectClient(address.port); await c.hello({nick}); clients.push(c);
  }
  clients[0].send({t:'create_room',gameId:'arcade',capacity:2});
  const roomA=(await clients[0].next(m=>m.t==='room')).room.code;
  clients[2].send({t:'create_room',gameId:'arcade',capacity:2});
  const roomB=(await clients[2].next(m=>m.t==='room')).room.code;
  clients[1].send({t:'join_room',code:roomA}); await clients[1].next(m=>m.t==='room'&&m.room.code===roomA);
  clients[3].send({t:'join_room',code:roomB}); await clients[3].next(m=>m.t==='room'&&m.room.code===roomB);
  gameCodes=true;
  const playA=clients[0].next(m=>m.t==='play',5000);
  const playB=clients[2].next(m=>m.t==='play',5000);
  for(const c of clients) c.send({t:'set_ready',ready:true});
  const [a,b]=await Promise.all([playA,playB]);
  const gameA=new URL(a.url).searchParams.get('room');
  const gameB=new URL(b.url).searchParams.get('room');
  console.log('Distinct Hub rooms:',roomA,roomB,'distinct:',roomA!==roomB);
  console.log('Concurrent initial free-state checks:',stateLookups);
  console.log('Assigned game codes:',gameA,gameB,'equal:',gameA===gameB);
  if(gameA!==gameB) throw new Error('Probe did not reproduce the suspected race');
  const g1=await openGame(); const first=waitWsMessage(g1,m=>m.t==='joined'||m.t==='err');
  g1.send(JSON.stringify({t:'create',room:gameA,name:'Alpha'}));
  const firstResult=await first;
  const g2=await openGame(); const collision=waitWsMessage(g2,m=>m.t==='joined'||m.t==='err');
  g2.send(JSON.stringify({t:'create',room:gameB,name:'Charlie'}));
  const collisionResult=await collision;
  const retry=waitWsMessage(g2,m=>m.t==='joined'||m.t==='err');
  g2.send(JSON.stringify({t:'join',room:gameB,name:'Charlie'}));
  const retryResult=await retry;
  console.log('Real Arcade results:', JSON.stringify({first:firstResult.t,collision:collisionResult.code,retry:retryResult.t,joinedRoom:retryResult.room,players:retryResult.state?.players?.map(p=>p.dname)}));
  if(firstResult.t!=='joined'||collisionResult.code!=='CODE_TAKEN'||retryResult.t!=='joined') throw new Error('Arcade fallback sequence did not reproduce');
} finally {
  for(const ws of gameClients) ws.terminate();
  await Promise.all(clients.map(c=>c.close()));
  await hub.close();
  await new Promise(resolve=>proxy.close(resolve));
  await arcade.close();
  crypto.randomInt=originalRandomInt; syncBuiltinESMExports();
}
